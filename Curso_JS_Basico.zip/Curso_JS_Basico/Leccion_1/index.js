// Este es el mensaje de bienvenida
console.log("Esta es la puerta de entrada al proytecto de JavaScript")

/*
Esta es la parte intermedia de nuestro proyecto
En esta parte realizamos los chequeos necesarios
Por ultimo vamos a la ultima linea de saludo
*/

//Este es el mensaje que se envia para despedir
console.log("Adios")