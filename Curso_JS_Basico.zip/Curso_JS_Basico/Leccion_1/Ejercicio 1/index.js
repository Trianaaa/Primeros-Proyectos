//Mensaje para mostrar en pantalla
console.log("Hola, este es mi primer ejercicio con Node en el mejor Bootcamp de programacion del mundo")